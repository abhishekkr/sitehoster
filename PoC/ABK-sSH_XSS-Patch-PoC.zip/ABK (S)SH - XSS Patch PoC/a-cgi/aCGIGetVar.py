#!python

## #########################
## it's kind of lib a Developer will need to
## use data provided by Web Server to access
## Client's data and Web 2.0 features
## #########################

def getValue(args,varRequired):
	for arg in args:
		if arg.split("=")[0] != arg:
			if arg.split("=")[0] == varRequired:
				return arg.split("=")[1]

def restoreRegisteredChar(response):
    response=response.replace("%20"," ")
    response=response.replace("%3b",";")
    response=response.replace("%3B",";")
    response=response.replace("%2f","/")
    response=response.replace("%2F","/")
    response=response.replace("%3f","?")
    response=response.replace("%3F","?")
    response=response.replace("%3a",":")
    response=response.replace("%3A",":")
    response=response.replace("%40","@")
    response=response.replace("%26","&")
    response=response.replace("%3d","=")
    response=response.replace("%3D","=")
    response=response.replace("%2b","+")
    response=response.replace("%2B","+")
    response=response.replace("%24","$")
    response=response.replace("%2c",",")
    response=response.replace("%2C",",")
    response=response.replace("%5b","[")
    response=response.replace("%5B","[")
    response=response.replace("%5d","]")
    response=response.replace("%5D","]")
    response=response.replace("%22","\"")
    response=response.replace("%3c","<")
    response=response.replace("%3C","<")
    response=response.replace("%3e",">")
    response=response.replace("%3E",">")
    return response