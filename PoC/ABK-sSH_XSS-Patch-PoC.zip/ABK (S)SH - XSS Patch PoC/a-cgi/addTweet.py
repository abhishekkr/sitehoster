#!python

import csv
import sys
import time

import aCGIGetVar

def addTweet(args):
    tweet=aCGIGetVar.getValue(args,"tweet")
    #print "<br/>",tweet,"<br/>"
    tweet=aCGIGetVar.restoreRegisteredChar(tweet)
    #print "<br/>",tweet,"<br/>"
    tweetWriter = csv.writer(open('tweet.csv','a'), delimiter='`', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    tweetWriter.writerow([time.strftime("%H:%M:%S %d %B '%Y"),tweet])
    print '<div class="nutweet">Tweet Added!</div>'

def readTweet():
    tweetReader = csv.reader(open('tweet.csv', 'rb'), delimiter='`', quotechar='|')
    tweetCount=0
    tweetDB=""
    for row in tweetReader:
        tweetCount = tweetCount+1
        tweetDB = tweetDB + '<div class="nutweet"><span class="datweet">'
        tweetDB = tweetDB + '</span><br/><span class="txtweet">'.join(row)
        tweetDB = tweetDB + '</span></div>'
    tweetCount = tweetCount-1
    if tweetCount==0:
        print '<div>'
        print 'ZERO TweeTexT Found... Add Some Now :)'
        print '</div>'
    else:
        print "<div>There are total ",tweetCount," TweeTexT(s)</div>"
        print tweetDB

def delTweet():
    tweetWriter = csv.writer(open('tweet.csv','wb'), delimiter='`', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    tweetWriter.writerow([])
    print '<div class="notweet">Tweet DB Deleted!</div>'
        
        
def iMain():
    try:
        if __name__ == "__main__":
            axn = aCGIGetVar.getValue(sys.argv,"axn")
            if axn=="add":
                addTweet(sys.argv)
            elif axn=="read":
                #print "read"
                readTweet()
            elif axn=="delAll":
                #print "delete"
                delTweet()
            else:
                print "Unknown Action is Desired... Please Check"
    except:
        print "PyError :("

iMain()