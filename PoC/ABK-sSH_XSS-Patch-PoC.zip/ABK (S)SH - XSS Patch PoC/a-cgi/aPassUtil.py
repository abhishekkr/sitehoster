#!python

#system Libs
import hashlib

def md5sum(txt):
    return hashlib.md5(txt).hexdigest()


def userSecret(id):
	if id == "ABK":
		return md5sum("its1lamepassword")
	if id == "root":
		return md5sum("tooroot")
	if id == "abionic":
		return md5sum("xss")
	if id == "devcamp2010":
		return md5sum("xss")
	if id == "hackers":
		return md5sum("xss")
